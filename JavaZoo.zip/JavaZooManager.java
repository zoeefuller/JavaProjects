public class ZooManager {
	
	public static void main(String [] args) {
		Elephant edgar = new Elephant("edgar");
		edgar.exercise();
		edgar.entertain();
		edgar.exercise();	
		edgar.sleep();
		edgar.exercise();
		edgar.exercise();
		edgar.feed();
			
	}
}
